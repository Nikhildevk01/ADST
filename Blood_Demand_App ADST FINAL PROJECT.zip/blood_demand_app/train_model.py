"""
Train the blood-demand model.

Run:  python train_model.py
Outputs: models/model.joblib  and  models/model_info.json
"""
import json
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import TimeSeriesSplit, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")
BASE = Path(__file__).parent
DATA = BASE / "data" / "Blood_Bank_Data_Cleaned.csv"
OUT = BASE / "models"
OUT.mkdir(exist_ok=True)

TARGET = "PredictedBloodDemand"
FEATURES = [
    "DayOfWeek", "Month", "IsWeekend", "Population", "Events",
    "HistoricalBloodUsage", "HospitalAdmissions", "BloodDonorsAvailable", "Temperature",
]
GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]


def metrics(y, p):
    return {
        "MAE": round(float(mean_absolute_error(y, p)), 2),
        "RMSE": round(float(np.sqrt(mean_squared_error(y, p))), 2),
        "R2": round(float(r2_score(y, p)), 4),
        "MAPE": round(float(np.mean(np.abs((y - p) / y)) * 100), 2),
    }


def main():
    df = pd.read_csv(DATA, parse_dates=["Date"]).sort_values("Date").reset_index(drop=True)
    print(f"Loaded {len(df)} rows  {df.Date.min().date()} -> {df.Date.max().date()}")

    # Time-based split: last year is the hold-out test set
    train = df[df.Date < "2024-01-01"]
    test = df[df.Date >= "2024-01-01"]
    Xtr, ytr, Xte, yte = train[FEATURES], train[TARGET], test[FEATURES], test[TARGET]

    candidates = {
        "Linear Regression": make_pipeline(StandardScaler(), LinearRegression()),
        "Ridge Regression": make_pipeline(StandardScaler(), Ridge(alpha=10)),
        "Random Forest": RandomForestRegressor(n_estimators=300, min_samples_leaf=3, random_state=42, n_jobs=-1),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.05, random_state=42),
    }

    # naive baseline = yesterday's demand
    naive = df[TARGET].shift(1).bfill()
    comparison = [{"model": "Naive (previous day)", **metrics(yte, naive.loc[test.index]), "CV_R2": None}]

    fitted = {}
    for name, model in candidates.items():
        cv = cross_val_score(model, df[FEATURES], df[TARGET], cv=TimeSeriesSplit(5), scoring="r2").mean()
        model.fit(Xtr, ytr)
        m = metrics(yte, model.predict(Xte))
        comparison.append({"model": name, **m, "CV_R2": round(float(cv), 4)})
        fitted[name] = model
        print(f"{name:20s} {m}  CV R2={cv:.4f}")

    best_name = min(
        (c for c in comparison if c["model"] in candidates), key=lambda c: c["RMSE"]
    )["model"]
    print("Best model:", best_name)

    best = fitted[best_name]
    pred_te = best.predict(Xte)
    resid = yte.values - pred_te
    lo, hi = np.percentile(resid, [5, 95])

    imp = permutation_importance(best, Xte, yte, n_repeats=15, random_state=42, scoring="r2")
    importance = sorted(
        [{"feature": f, "importance": round(float(v), 4)} for f, v in zip(FEATURES, imp.importances_mean)],
        key=lambda d: d["importance"], reverse=True,
    )

    # Blood-group split = historical share of each group in total demand
    shares = {g: float(df[f"Demand_{g}"].sum() / df[TARGET].sum()) for g in GROUPS}
    donor_shares = {g: float(df[f"Donors_{g}"].sum() / df["BloodDonorsAvailable"].sum()) for g in GROUPS}

    # Final model: refit on ALL data for deployment
    final = candidates[best_name]
    final.fit(df[FEATURES], df[TARGET])

    joblib.dump({"model": final, "features": FEATURES}, OUT / "model.joblib")

    info = {
        "best_model": best_name,
        "features": FEATURES,
        "train_rows": int(len(train)), "test_rows": int(len(test)),
        "train_period": [str(train.Date.min().date()), str(train.Date.max().date())],
        "test_period": [str(test.Date.min().date()), str(test.Date.max().date())],
        "test_metrics": metrics(yte, pred_te),
        "comparison": comparison,
        "interval": {"lo": round(float(lo), 2), "hi": round(float(hi), 2)},
        "importance": importance,
        "group_shares": shares,
        "donor_shares": donor_shares,
        "test_series": {
            "dates": [d.strftime("%Y-%m-%d") for d in test.Date],
            "actual": [int(v) for v in yte],
            "predicted": [round(float(v), 1) for v in pred_te],
        },
    }
    (OUT / "model_info.json").write_text(json.dumps(info, indent=2))
    print("Saved models/model.joblib and models/model_info.json")


if __name__ == "__main__":
    main()
