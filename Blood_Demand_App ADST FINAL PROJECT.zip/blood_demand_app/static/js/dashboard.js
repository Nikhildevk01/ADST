const RED = '#c62839', BLUE = '#3b6fd4', GREY = '#9aa3b5';
const charts = {};
function draw(id, cfg) {
  if (charts[id]) charts[id].destroy();
  cfg.options = Object.assign({responsive: true, maintainAspectRatio: false}, cfg.options || {});
  charts[id] = new Chart(document.getElementById(id), cfg);
}
const fmt = n => Number(n).toLocaleString();

async function load() {
  const year = document.getElementById('year').value;
  const d = await (await fetch('/api/dashboard?year=' + year)).json();
  const k = d.kpi;
  document.getElementById('k-total').textContent = fmt(k.total_demand);
  document.getElementById('k-avg').textContent = k.avg_demand;
  document.getElementById('k-peak').textContent = k.peak_demand;
  document.getElementById('k-peakd').textContent = k.peak_date;
  document.getElementById('k-short').textContent = k.shortage_pct + '%';
  document.getElementById('uplift').textContent = k.event_uplift ? '(+' + k.event_uplift + '% on event days)' : '';

  draw('c-monthly', {type: 'line', data: {labels: d.monthly.labels, datasets: [
    {label: 'Avg demand', data: d.monthly.demand, borderColor: RED, backgroundColor: RED + '22', fill: true, tension: .3, pointRadius: 2},
    {label: 'Avg donors', data: d.monthly.donors, borderColor: BLUE, tension: .3, pointRadius: 2}]}});
  draw('c-groups', {type: 'bar', data: {labels: d.groups.labels, datasets: [
    {label: 'Demand', data: d.groups.demand, backgroundColor: RED}, {label: 'Donors', data: d.groups.donors, backgroundColor: BLUE}]}});
  draw('c-dow', {type: 'bar', data: {labels: d.dow.labels, datasets: [{label: 'Avg demand', data: d.dow.values, backgroundColor: RED}]},
    options: {plugins: {legend: {display: false}}, scales: {y: {beginAtZero: true}}}});
  draw('c-events', {type: 'bar', data: {labels: d.events.labels, datasets: [{label: 'Avg demand', data: d.events.values, backgroundColor: [GREY, RED]}]},
    options: {plugins: {legend: {display: false}}, scales: {y: {beginAtZero: true}}}});
  draw('c-yearly', {type: 'bar', data: {labels: d.yearly.labels, datasets: [{label: 'Total units', data: d.yearly.values, backgroundColor: RED}]},
    options: {plugins: {legend: {display: false}}, scales: {y: {beginAtZero: true}}}});
  draw('c-recent', {type: 'line', data: {labels: d.recent.labels, datasets: [
    {label: 'Demand', data: d.recent.demand, borderColor: RED, tension: .25, pointRadius: 0},
    {label: 'Donors', data: d.recent.donors, borderColor: BLUE, tension: .25, pointRadius: 0}]}});
}
document.getElementById('year').addEventListener('change', load);
load();
