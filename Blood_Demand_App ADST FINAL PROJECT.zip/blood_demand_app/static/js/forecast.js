let chart, events = [], lastRows = [];
const form = document.getElementById('fform');

function renderChips() {
  document.getElementById('evlist').innerHTML = events.map(e =>
    `<span class="chip">🎪 ${e}<button type="button" data-d="${e}">×</button></span>`).join('');
}
document.getElementById('evadd').onclick = () => {
  const v = document.getElementById('evdate').value;
  if (v && !events.includes(v)) { events.push(v); events.sort(); renderChips(); }
};
document.getElementById('evlist').onclick = e => {
  if (e.target.dataset.d) { events = events.filter(x => x !== e.target.dataset.d); renderChips(); }
};

form.addEventListener('submit', async e => {
  e.preventDefault();
  const res = await postJSON('/api/forecast', {start: form.start.value, days: form.days.value, donors: form.donors.value, events})
    .catch(err => { alert(err.message); });
  if (!res) return;
  lastRows = res.rows;
  const s = res.summary;
  document.getElementById('fout').classList.remove('hidden');
  document.getElementById('s-total').textContent = s.total.toLocaleString();
  document.getElementById('s-avg').textContent = s.avg;
  document.getElementById('s-peak').textContent = s.peak;
  document.getElementById('s-peakd').textContent = s.peak_date;
  document.getElementById('s-crit').textContent = s.critical_days;
  document.getElementById('s-extra').textContent = s.extra_donors + ' extra donors advised in total';
  document.getElementById('dlrows').value = JSON.stringify(res.rows);

  const labels = res.rows.map(r => r.date.slice(5));
  if (chart) chart.destroy();
  chart = new Chart(document.getElementById('f-chart'), {type: 'line', data: {labels, datasets: [
    {label: 'Upper (95th pct)', data: res.rows.map(r => r.upper), borderColor: 'transparent', backgroundColor: '#c6283922', fill: '+1', pointRadius: 0},
    {label: 'Lower (5th pct)', data: res.rows.map(r => r.lower), borderColor: 'transparent', pointRadius: 0},
    {label: 'Predicted demand', data: res.rows.map(r => r.predicted), borderColor: '#c62839', tension: .25, pointRadius: res.rows.map(r => r.event ? 6 : 2), pointBackgroundColor: res.rows.map(r => r.event ? '#e69a14' : '#c62839')},
    {label: 'Donors available', data: res.rows.map(r => r.donors), borderColor: '#3b6fd4', borderDash: [6, 4], pointRadius: 0}]},
    options: {responsive: true, maintainAspectRatio: false, plugins: {legend: {labels: {filter: i => !i.text.includes('pct')}}}}});

  let h = '<thead><tr><th>Date</th><th>Day</th><th>Event</th><th>Predicted</th><th>Range</th><th>Donors</th><th>Gap</th><th>Status</th></tr></thead><tbody>';
  res.rows.forEach(r => {
    h += `<tr><td>${r.date}</td><td>${r.day.slice(0, 3)}</td><td>${r.event ? '🎪' : ''}</td><td><b>${r.predicted}</b></td><td>${r.lower}–${r.upper}</td><td>${r.donors}</td><td>${r.gap}</td>
    <td><span class="badge s-${r.status.split(' ')[0].toLowerCase()}">${r.status}</span></td></tr>`; });
  document.getElementById('f-table').innerHTML = h + '</tbody>';
});
