let chart;
const form = document.getElementById('pform');
form.addEventListener('submit', async e => {
  e.preventDefault();
  const btn = document.getElementById('pbtn');
  const f = new FormData(form);
  const body = Object.fromEntries(f.entries());
  body.event = form.event.checked;
  btn.disabled = true; btn.textContent = 'Predicting…';
  try {
    show(await postJSON('/api/predict', body));
  } catch (err) { alert(err.message); }
  btn.disabled = false; btn.textContent = 'Predict demand';
});

function show(r) {
  document.getElementById('placeholder').classList.add('hidden');
  document.getElementById('result').classList.remove('hidden');
  document.getElementById('r-date').textContent = r.day + ', ' + r.date;
  document.getElementById('r-total').textContent = r.predicted;
  document.getElementById('r-range').textContent = '90% likely range: ' + r.lower + ' – ' + r.upper + ' units';
  document.getElementById('r-donors').textContent = r.donors;
  document.getElementById('r-gap').textContent = (r.gap > 0 ? '+' : '') + r.gap;
  document.getElementById('r-need').textContent = r.donors_needed;
  const s = document.getElementById('r-status');
  s.textContent = r.status;
  s.className = 'badge s-' + r.status.split(' ')[0].toLowerCase();

  const labels = Object.keys(r.groups);
  if (chart) chart.destroy();
  chart = new Chart(document.getElementById('r-chart'), {type: 'bar', data: {labels, datasets: [
    {label: 'Predicted demand', data: labels.map(g => r.groups[g]), backgroundColor: '#c62839'},
    {label: 'Est. donors', data: labels.map(g => r.donor_groups[g]), backgroundColor: '#3b6fd4'}]},
    options: {responsive: true, maintainAspectRatio: false}});

  let h = '<thead><tr><th>Group</th><th>Demand</th><th>Est. donors</th><th>Gap</th></tr></thead><tbody>';
  labels.forEach(g => { const gap = r.donor_groups[g] - r.groups[g];
    h += `<tr><td><b>${g}</b></td><td>${r.groups[g]}</td><td>${r.donor_groups[g]}</td><td style="color:${gap < 0 ? '#c62839' : '#1f9d63'}">${gap > 0 ? '+' : ''}${gap}</td></tr>`; });
  document.getElementById('r-table').innerHTML = h + '</tbody>';
}
