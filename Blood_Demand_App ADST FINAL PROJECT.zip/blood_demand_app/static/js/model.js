(async () => {
  const d = await (await fetch('/api/model')).json();
  new Chart(document.getElementById('m-series'), {type: 'line', data: {labels: d.series.dates, datasets: [
    {label: 'Actual', data: d.series.actual, borderColor: '#9aa3b5', pointRadius: 0, borderWidth: 1.3},
    {label: 'Predicted', data: d.series.predicted, borderColor: '#c62839', pointRadius: 0, borderWidth: 1.6}]},
    options: {responsive: true, maintainAspectRatio: false, scales: {x: {ticks: {maxTicksLimit: 8}}}}});
  const imp = d.importance.filter(i => i.importance > 0.0005);
  new Chart(document.getElementById('m-imp'), {type: 'bar', data: {labels: imp.map(i => i.feature),
    datasets: [{label: 'Permutation importance (R² drop)', data: imp.map(i => i.importance), backgroundColor: '#c62839'}]},
    options: {indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: {legend: {display: false}}}});
})();
