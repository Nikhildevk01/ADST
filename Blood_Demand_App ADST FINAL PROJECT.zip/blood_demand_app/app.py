"""
BloodCast - Blood Demand Forecasting web app (Flask)

Run:  python app.py      ->  http://127.0.0.1:5000
"""
import csv
import io
import json
import secrets
import sqlite3
from datetime import date, datetime, timedelta
from functools import wraps
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from flask import (Flask, Response, abort, flash, g, jsonify, redirect,
                   render_template, request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE = Path(__file__).parent
DB_PATH = BASE / "instance" / "bloodcast.db"
DATA_PATH = BASE / "data" / "Blood_Bank_Data_Cleaned.csv"
MODEL_PATH = BASE / "models" / "model.joblib"
INFO_PATH = BASE / "models" / "model_info.json"

GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]

app = Flask(__name__)
# Change this (or set the SECRET_KEY environment variable) before deploying
import os
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-me-in-production-" + "bloodcast")

# --------------------------------------------------------------------------
# Load data + model once at start-up
# --------------------------------------------------------------------------
if not MODEL_PATH.exists():
    raise SystemExit("Model not found. Run:  python train_model.py")

df = pd.read_csv(DATA_PATH, parse_dates=["Date"]).sort_values("Date").reset_index(drop=True)
bundle = joblib.load(MODEL_PATH)
MODEL, FEATURES = bundle["model"], bundle["features"]
INFO = json.loads(INFO_PATH.read_text())
SHARES = INFO["group_shares"]
LAST_DATE = df.Date.max().date()

# Typical driver values per month (used for future forecasts)
MONTHLY_DRIVERS = df.groupby("Month")[
    ["Population", "HistoricalBloodUsage", "HospitalAdmissions", "BloodDonorsAvailable", "Temperature"]
].mean()
DEFAULTS = {
    "population": int(df.Population.mean()),
    "historical_usage": int(df.HistoricalBloodUsage.mean()),
    "hospital_admissions": int(df.HospitalAdmissions.mean()),
    "donors_available": int(df.BloodDonorsAvailable.mean()),
    "temperature": round(float(df.Temperature.mean()), 1),
}


# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS predictions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            target_date TEXT NOT NULL,
            inputs TEXT NOT NULL,
            predicted INTEGER NOT NULL,
            donors INTEGER NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, email TEXT NOT NULL,
            subject TEXT NOT NULL, message TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )
    # Default admin account (change the password after first login!)
    if not db.execute("SELECT 1 FROM users WHERE email='admin@bloodcast.com'").fetchone():
        db.execute(
            "INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
            ("Administrator", "admin@bloodcast.com", generate_password_hash("admin123"),
             "admin", datetime.now().isoformat(timespec="seconds")),
        )
    db.commit()
    db.close()


init_db()


# --------------------------------------------------------------------------
# Auth + CSRF
# --------------------------------------------------------------------------
def login_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*a, **kw)
    return wrapped


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*a, **kw):
        if session.get("role") != "admin":
            abort(403)
        return view(*a, **kw)
    return wrapped


def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token


@app.before_request
def check_csrf():
    if request.method == "POST":
        token = request.form.get("_csrf") or request.headers.get("X-CSRF-Token")
        if not token or token != session.get("_csrf"):
            abort(400, "Invalid or missing CSRF token. Refresh the page and try again.")


@app.context_processor
def inject_globals():
    return {"current_year": date.today().year, "model_name": INFO["best_model"]}


# --------------------------------------------------------------------------
# Prediction logic
# --------------------------------------------------------------------------
def build_row(d: date, population, events, usage, admissions, donors, temp):
    return pd.DataFrame([{
        "DayOfWeek": d.weekday(), "Month": d.month, "IsWeekend": int(d.weekday() >= 5),
        "Population": population, "Events": int(events), "HistoricalBloodUsage": usage,
        "HospitalAdmissions": admissions, "BloodDonorsAvailable": donors, "Temperature": temp,
    }])[FEATURES]


def status_for(demand, donors):
    gap = donors - demand
    ratio = donors / demand if demand else 9
    if ratio >= 1.0:
        return "Surplus" if ratio >= 1.15 else "Balanced", gap
    if ratio >= 0.6:
        return "Low Stock", gap
    return "Critical Shortage", gap


def predict_one(d, population, events, usage, admissions, donors, temp):
    raw = float(MODEL.predict(build_row(d, population, events, usage, admissions, donors, temp))[0])
    total = max(int(round(raw)), 0)
    lo = max(int(round(raw + INFO["interval"]["lo"])), 0)
    hi = int(round(raw + INFO["interval"]["hi"]))
    groups = {g: int(round(total * SHARES[g])) for g in GROUPS}
    donor_groups = {g: int(round(donors * INFO["donor_shares"][g])) for g in GROUPS}
    status, gap = status_for(total, donors)
    return {
        "date": d.isoformat(), "day": d.strftime("%A"), "predicted": total, "lower": lo, "upper": hi,
        "groups": groups, "donor_groups": donor_groups, "donors": int(donors),
        "gap": int(gap), "status": status,
        "donors_needed": max(hi - int(donors), 0),
    }


# --------------------------------------------------------------------------
# Public pages
# --------------------------------------------------------------------------
@app.route("/")
def index():
    stats = {
        "days": len(df), "avg": int(df.PredictedBloodDemand.mean()),
        "r2": INFO["test_metrics"]["R2"], "mae": INFO["test_metrics"]["MAE"],
    }
    return render_template("index.html", stats=stats)


@app.route("/about")
def about():
    return render_template("about.html", info=INFO, n=len(df),
                           period=(df.Date.min().date(), df.Date.max().date()))


@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        subject = request.form.get("subject", "").strip()
        message = request.form.get("message", "").strip()
        if not (name and email and subject and message) or "@" not in email:
            flash("Please fill in all fields with a valid email address.", "danger")
        else:
            db = get_db()
            db.execute("INSERT INTO messages(name,email,subject,message,created_at) VALUES(?,?,?,?,?)",
                       (name, email, subject[:150], message[:3000], datetime.now().isoformat(timespec="seconds")))
            db.commit()
            flash("Thank you! Your message has been received.", "success")
            return redirect(url_for("contact"))
    return render_template("contact.html")


# --------------------------------------------------------------------------
# Authentication
# --------------------------------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        pw, pw2 = request.form.get("password", ""), request.form.get("confirm", "")
        error = None
        if not name or "@" not in email:
            error = "Enter your name and a valid email."
        elif len(pw) < 6:
            error = "Password must be at least 6 characters."
        elif pw != pw2:
            error = "Passwords do not match."
        if not error:
            db = get_db()
            try:
                db.execute("INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",
                           (name, email, generate_password_hash(pw), datetime.now().isoformat(timespec="seconds")))
                db.commit()
                flash("Account created. Please log in.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                error = "An account with that email already exists."
        flash(error, "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], request.form.get("password", "")):
            session.clear()
            session.update(user_id=user["id"], name=user["name"], role=user["role"])
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    if request.method == "POST":
        cur, new, new2 = (request.form.get(k, "") for k in ("current", "new", "confirm"))
        if not check_password_hash(user["password_hash"], cur):
            flash("Current password is incorrect.", "danger")
        elif len(new) < 6 or new != new2:
            flash("New passwords must match and be at least 6 characters.", "danger")
        else:
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), user["id"]))
            db.commit()
            flash("Password updated.", "success")
        return redirect(url_for("profile"))
    count = db.execute("SELECT COUNT(*) FROM predictions WHERE user_id=?", (user["id"],)).fetchone()[0]
    return render_template("profile.html", user=user, count=count)


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    years = sorted(df.Year.unique().tolist())
    return render_template("dashboard.html", years=years)


@app.route("/api/dashboard")
@login_required
def api_dashboard():
    year = request.args.get("year", "all")
    d = df if year == "all" else df[df.Year == int(year)]
    if d.empty:
        return jsonify({"error": "No data"}), 404
    monthly = d.groupby(d.Date.dt.to_period("M")).agg(
        demand=("PredictedBloodDemand", "mean"), donors=("BloodDonorsAvailable", "mean"))
    dow = d.groupby("DayOfWeek").PredictedBloodDemand.mean()
    names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    yearly = df.groupby("Year").PredictedBloodDemand.sum()
    recent = df.tail(60)
    short = d[d.Demand_Gap < 0]
    return jsonify({
        "kpi": {
            "total_demand": int(d.PredictedBloodDemand.sum()),
            "avg_demand": round(float(d.PredictedBloodDemand.mean()), 1),
            "peak_demand": int(d.PredictedBloodDemand.max()),
            "peak_date": d.loc[d.PredictedBloodDemand.idxmax(), "Date"].strftime("%d %b %Y"),
            "avg_donors": round(float(d.BloodDonorsAvailable.mean()), 1),
            "shortage_pct": round(len(short) / len(d) * 100, 1),
            "event_uplift": round(float(d[d.Events == 1].PredictedBloodDemand.mean() /
                                        d[d.Events == 0].PredictedBloodDemand.mean() * 100 - 100), 1)
            if (d.Events == 1).any() else 0,
        },
        "monthly": {"labels": [str(p) for p in monthly.index],
                    "demand": monthly.demand.round(1).tolist(), "donors": monthly.donors.round(1).tolist()},
        "groups": {"labels": GROUPS,
                   "demand": [int(d[f"Demand_{g}"].sum()) for g in GROUPS],
                   "donors": [int(d[f"Donors_{g}"].sum()) for g in GROUPS]},
        "dow": {"labels": names, "values": [round(float(dow[i]), 1) for i in range(7)]},
        "yearly": {"labels": [str(y) for y in yearly.index], "values": yearly.astype(int).tolist()},
        "recent": {"labels": recent.Date.dt.strftime("%d %b").tolist(),
                   "demand": recent.PredictedBloodDemand.tolist(), "donors": recent.BloodDonorsAvailable.tolist()},
        "events": {"labels": ["Normal days", "Event days"],
                   "values": [round(float(d[d.Events == 0].PredictedBloodDemand.mean()), 1),
                              round(float(d[d.Events == 1].PredictedBloodDemand.mean()), 1) if (d.Events == 1).any() else 0]},
    })


# --------------------------------------------------------------------------
# Prediction
# --------------------------------------------------------------------------
@app.route("/predict")
@login_required
def predict():
    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    return render_template("predict.html", defaults=DEFAULTS, tomorrow=tomorrow)


@app.route("/api/predict", methods=["POST"])
@login_required
def api_predict():
    p = request.get_json(silent=True) or {}
    try:
        d = datetime.strptime(p["date"], "%Y-%m-%d").date()
        population = int(p["population"]); usage = int(p["historical_usage"])
        admissions = int(p["hospital_admissions"]); donors = int(p["donors_available"])
        temp = float(p["temperature"]); event = 1 if p.get("event") else 0
        if min(population, usage, admissions, donors) < 0 or not -10 <= temp <= 60:
            raise ValueError
    except (KeyError, ValueError, TypeError):
        return jsonify({"error": "Please enter valid numbers for all fields."}), 400

    res = predict_one(d, population, event, usage, admissions, donors, temp)
    db = get_db()
    db.execute("INSERT INTO predictions(user_id,target_date,inputs,predicted,donors,status,created_at) VALUES(?,?,?,?,?,?,?)",
               (session["user_id"], res["date"], json.dumps({**p, "event": event}), res["predicted"],
                donors, res["status"], datetime.now().isoformat(timespec="seconds")))
    db.commit()
    return jsonify(res)


# --------------------------------------------------------------------------
# Forecast (multi-day)
# --------------------------------------------------------------------------
def make_forecast(start: date, days: int, event_dates: set, donors_override=None):
    rows = []
    for i in range(days):
        d = start + timedelta(days=i)
        m = MONTHLY_DRIVERS.loc[d.month]
        donors = int(donors_override) if donors_override else int(round(m.BloodDonorsAvailable))
        r = predict_one(d, int(round(m.Population)), 1 if d.isoformat() in event_dates else 0,
                        int(round(m.HistoricalBloodUsage)), int(round(m.HospitalAdmissions)),
                        donors, round(float(m.Temperature), 1))
        rows.append(r)
    return rows


@app.route("/forecast")
@login_required
def forecast():
    return render_template("forecast.html", tomorrow=(date.today() + timedelta(days=1)).isoformat())


@app.route("/api/forecast", methods=["POST"])
@login_required
def api_forecast():
    p = request.get_json(silent=True) or {}
    try:
        start = datetime.strptime(p["start"], "%Y-%m-%d").date()
        days = max(1, min(int(p.get("days", 14)), 90))
        events = {datetime.strptime(e, "%Y-%m-%d").date().isoformat() for e in p.get("events", [])}
        donors = int(p["donors"]) if p.get("donors") not in (None, "") else None
    except (KeyError, ValueError, TypeError):
        return jsonify({"error": "Invalid forecast settings."}), 400
    rows = make_forecast(start, days, events, donors)
    for r in rows:
        r["event"] = r["date"] in events
    total = sum(r["predicted"] for r in rows)
    peak = max(rows, key=lambda r: r["predicted"])
    return jsonify({
        "rows": rows,
        "summary": {"total": total, "avg": round(total / len(rows), 1),
                    "peak": peak["predicted"], "peak_date": peak["date"],
                    "critical_days": sum(r["status"] == "Critical Shortage" for r in rows),
                    "extra_donors": sum(r["donors_needed"] for r in rows)},
    })


@app.route("/forecast/download", methods=["POST"])
@login_required
def forecast_download():
    rows = json.loads(request.form.get("rows", "[]"))
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Date", "Day", "Predicted demand", "Lower", "Upper", "Donors available", "Gap", "Status"] + GROUPS)
    for r in rows:
        w.writerow([r["date"], r["day"], r["predicted"], r["lower"], r["upper"], r["donors"], r["gap"], r["status"]]
                   + [r["groups"][g] for g in GROUPS])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=blood_demand_forecast.csv"})


# --------------------------------------------------------------------------
# History of saved predictions
# --------------------------------------------------------------------------
@app.route("/history")
@login_required
def history():
    rows = get_db().execute("SELECT * FROM predictions WHERE user_id=? ORDER BY id DESC LIMIT 200",
                            (session["user_id"],)).fetchall()
    return render_template("history.html", rows=rows)


@app.route("/history/delete/<int:pid>", methods=["POST"])
@login_required
def history_delete(pid):
    db = get_db()
    db.execute("DELETE FROM predictions WHERE id=? AND user_id=?", (pid, session["user_id"]))
    db.commit()
    flash("Prediction removed.", "info")
    return redirect(url_for("history"))


@app.route("/history/export")
@login_required
def history_export():
    rows = get_db().execute("SELECT * FROM predictions WHERE user_id=? ORDER BY id DESC", (session["user_id"],)).fetchall()
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Target date", "Predicted demand", "Donors available", "Status", "Created"])
    for r in rows:
        w.writerow([r["target_date"], r["predicted"], r["donors"], r["status"], r["created_at"]])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=my_predictions.csv"})


# --------------------------------------------------------------------------
# Data explorer + model insights
# --------------------------------------------------------------------------
@app.route("/data")
@login_required
def data_explorer():
    page = max(int(request.args.get("page", 1)), 1)
    start, end = request.args.get("start", ""), request.args.get("end", "")
    d = df
    if start:
        d = d[d.Date >= start]
    if end:
        d = d[d.Date <= end]
    per = 20
    pages = max((len(d) - 1) // per + 1, 1)
    page = min(page, pages)
    chunk = d.sort_values("Date", ascending=False).iloc[(page - 1) * per: page * per]
    cols = ["Date", "Events", "HospitalAdmissions", "HistoricalBloodUsage", "BloodDonorsAvailable",
            "Temperature", "PredictedBloodDemand", "Demand_Gap"]
    records = chunk[cols].assign(Date=chunk.Date.dt.strftime("%Y-%m-%d")).to_dict("records")
    return render_template("data.html", records=records, cols=cols, page=page, pages=pages,
                           total=len(d), start=start, end=end)


@app.route("/data/download")
@login_required
def data_download():
    return Response(df.to_csv(index=False), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=Blood_Bank_Data_Cleaned.csv"})


@app.route("/model")
@login_required
def model_insights():
    return render_template("model.html", info=INFO)


@app.route("/api/model")
@login_required
def api_model():
    return jsonify({"importance": INFO["importance"], "series": INFO["test_series"]})


# --------------------------------------------------------------------------
# Admin
# --------------------------------------------------------------------------
@app.route("/admin")
@admin_required
def admin():
    db = get_db()
    return render_template(
        "admin.html",
        messages=db.execute("SELECT * FROM messages ORDER BY id DESC").fetchall(),
        users=db.execute("SELECT id,name,email,role,created_at FROM users ORDER BY id").fetchall(),
        npred=db.execute("SELECT COUNT(*) FROM predictions").fetchone()[0],
    )


# --------------------------------------------------------------------------
# Errors
# --------------------------------------------------------------------------
@app.errorhandler(400)
@app.errorhandler(403)
@app.errorhandler(404)
def error(e):
    return render_template("error.html", e=e), e.code


if __name__ == "__main__":
    app.run(debug=True)
