# 🩸 BloodCast – Blood Demand Forecasting Web App

A Flask web app that predicts daily blood demand from the `Blood_Bank_Data_Cleaned.csv` dataset
(1,827 daily records, 2020-2024).

## Pages
| Page | URL | Access |
|---|---|---|
| Home, About, Contact | `/`, `/about`, `/contact` | public |
| Sign up / Login / Logout | `/register`, `/login` | public |
| Dashboard (KPIs + 6 charts, year filter) | `/dashboard` | login |
| Prediction (single day, blood-group split, shortage status) | `/predict` | login |
| Multi-day forecast (7-90 days, event dates, CSV download) | `/forecast` | login |
| My prediction history (+ export, delete) | `/history` | login |
| Data explorer (filter, paginate, download CSV) | `/data` | login |
| Model insights (metrics, comparison, feature importance) | `/model` | login |
| Profile (change password) | `/profile` | login |
| Admin (users + contact messages) | `/admin` | admin |

## Quick start
```bash
# 1. (optional) create a virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # macOS / Linux

# 2. install dependencies
pip install -r requirements.txt

# 3. (optional) retrain the model - a trained model is already included
python train_model.py

# 4. run the app
python app.py
```
Open **http://127.0.0.1:5000**

**Demo admin login:** `admin@bloodcast.com` / `admin123` (change it in *Profile* after first login).
Or create your own account with *Sign up*.

> Charts use Chart.js from a CDN, so the browser needs an internet connection the first time.

## Project structure
```
blood_demand_app/
├── app.py                 # Flask app: routes, auth, API, prediction logic
├── train_model.py         # Data science pipeline: compare models, evaluate, save best
├── requirements.txt
├── data/Blood_Bank_Data_Cleaned.csv
├── models/model.joblib    # trained model (created by train_model.py)
├── models/model_info.json # metrics, importance, group shares
├── instance/bloodcast.db  # SQLite DB (auto-created on first run)
├── templates/             # HTML pages (Jinja2)
└── static/css, static/js  # styling + chart scripts
```

## Data science summary
* **Target:** `PredictedBloodDemand` (total units/day)
* **Features:** weekday, month, weekend flag, population, events, historical usage, hospital admissions, donors available, temperature
* **Validation:** time-based split (train 2020-2023, test 2024) + 5-fold time-series CV
* **Models compared:** Linear, Ridge, Random Forest, Gradient Boosting (+ naive "yesterday" baseline)
* **Blood-group split:** total demand x historical share of each group
* **Prediction interval:** 5th-95th percentile of hold-out residuals

## Notes / limitations
* In this dataset demand is driven mainly by `HistoricalBloodUsage`, donors available, hospital admissions and events.
  There is almost no seasonality or day-to-day autocorrelation, so multi-day forecasts use typical monthly conditions
  and show the expected level rather than exact daily swings.
* Donors available are on average far below demand in the data, so most days are flagged as shortage.
  Adjust the thresholds in `status_for()` in `app.py` if your real definition differs.
* Before deploying publicly, set a real `SECRET_KEY` environment variable and change the admin password.
